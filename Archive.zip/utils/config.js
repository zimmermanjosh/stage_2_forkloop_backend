module.exports = {
  JWT_SECRET: process.env.JWT_SECRET || "your_secret_key_here",
};